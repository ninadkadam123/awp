        function  CheckForRange(controlID,errDivID,errMsg,Min, Max)
        {
            var element = document.getElementById(controlID);
            var errDiv = document.getElementById(errDivID);
            if(element.value<Min || element.value>Max)
            {
                errDiv.innerHTML = errMsg;
            }
            else{
                errDiv.innerHTML = "";
            }

        }
        function CheckEmpty(controlID, errDivID, errMsg)
        {
            var element = document.getElementById(controlID);
            var errDiv = document.getElementById(errDivID);
            if (element.value == "")
            {
                errDiv.innerHTML = errMsg;
                return false;
            }
            else{
                errDiv.innerHTML = "";
                return true;
            }
        }

        function CheckForValidText(controlID, errDivID, errMsg)
        {
            var element = document.getElementById(controlID);
            var errDiv = document.getElementById(errDivID);
            

            if (!isNaN(element.value))
            {
                errDiv.innerHTML = errMsg;
                return false;
            }
            else{
                errDiv.innerHTML = "";
                return  true;
            }
        }

        function CheckForValidNumber(controlID, errDivID, errMsg)
        {
            var element = document.getElementById(controlID);
            var errDiv = document.getElementById(errDivID);
            

            if (isNaN(element.value))
            {
                errDiv.innerHTML = errMsg;
                return false;   
            }
            else{
                errDiv.innerHTML = "";
                return true;
            }
        }