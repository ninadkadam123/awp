<?php 
  $name = "";
  $address = "";
  $enoToBeEdited = "";

  session_start();
  if(!isset($_SESSION["userName"])){
      header("location:050PuneDemo.php");
  }
  else
  {
      if(isset($_POST["btnUpdate"]))
      {
        $refToConnection=       
                        mysqli_connect("localhost","root"
                       ,"manager","AWP");

        $query = 
            "update Emp set EName='" .$_POST["txtEName"] . "', EAddress='".$_POST["txtEAddress"]."' where ENo=".$_POST["txtENo"] ;

        //echo $query;
        $resultSet= mysqli_query($refToConnection, 
                                $query);
                               
                      
        $noOfRowsAffected= mysqli_affected_rows($refToConnection);

        if($noOfRowsAffected>0)
        {
            echo "Record Updated!";
        }
        else
        {
            echo "Something is wrong! ";
        }
      }
      else
      {
          //It means you navigated by clicking on 
          //Add Record Link provided in 051PuneDemo.php
          //or
          //navigated directly to this page 
          //after log in
          if(isset($_GET["ENo"]))
          {
            $enoToBeEdited = $_GET["ENo"];
            $refToConnection=       
                        mysqli_connect("localhost","root"
                       ,"manager","AWP");
            $query = 
                "select * from Emp where ENo= ".$enoToBeEdited;

            $resultset=   mysqli_query($refToConnection,$query);

            $currentRow= mysqli_fetch_row($resultset);
            
            $name = $currentRow[1];
            $address = $currentRow[2];
            mysqli_close($refToConnection);
          }
          else
          {
            echo "<h2>Enter Values for Fields by yourself!</h2>";
          }
      }
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
<form action="053PuneDemo.php" method="POST">
    <a href="051PuneDemo.php">Go Back to List</a><br>
    <h1>Update Record </h1>
    ENo: <input type="text" name="txtENo" id="txtENo" value="<?php echo $enoToBeEdited; ?>"><br>
    EName:<input type="text" name="txtEName" id="txtEName" value="<?php echo $name; ?>"><br>
    EAddress: <input type="text" name="txtEAddress" id="txtEAddress" value="<?php echo $address; ?>"><br>
    <input type="submit" value="Save Changes" name="btnUpdate">

</form>
</body>
</html>