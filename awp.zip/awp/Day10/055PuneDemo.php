<?php 
    session_start();
    unset($_SESSION["userName"]);
    header("location:051PuneDemo.php");
?>