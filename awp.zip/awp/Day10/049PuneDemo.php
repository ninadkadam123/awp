<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <h1>This is HTML content in PHP Page</h1>
    <h2>
        <?php 
            $a = 10;
            $b = 20;
            $c = $a + $b;
            echo $c;    
        ?>
    </h2>
</body>
</html>