<?php 
    echo "<b>Hi</b><br>";

    $a = 100;
    $b = 200;

    $c = $a + $b;
    echo $c;
    echo "<br>";
    echo $a.$b;

    $myData  = "Hello " . "World";
    echo $myData;
?>


<!-- <?php 
    echo "<h1>Hello</h1>";
?> -->