<?php 

        
       $refToConnection= 
                mysqli_connect("localhost","root"
                               ,"manager","AWP");
       $resultSet= 
                mysqli_query($refToConnection, 
                            "select * from Emp");

        
        $data= mysqli_fetch_all($resultSet);

        $jsonData =  json_encode($data);
        
        mysqli_close($refToConnection);

        header("Content-Type:application/json");
        echo $jsonData;



?>