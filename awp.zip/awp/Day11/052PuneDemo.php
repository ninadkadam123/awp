<?php 

   
  session_start();
  if(!isset($_SESSION["userName"])){
      header("location:050PuneDemo.php");
  }
  else
  {
      print_r($_POST);
      
      if(isset($_POST["btnAdd"]))
      {
        $refToConnection=       
                        mysqli_connect("localhost","root"
                       ,"manager","AWP");

        $query = "insert into Emp values(".
                  $_POST["txtENo"] . ",'". 
                  $_POST["txtEName"] . "','". 
                  $_POST["txtEAddress"]."')";

        //echo $query;
        $resultSet= mysqli_query($refToConnection, 
                                $query);
                               
                      
        $noOfRowsAffected= mysqli_affected_rows($refToConnection);
        //echo $noOfRowsAffected;

        if($noOfRowsAffected>0)
        {
            echo "Row Added!";
        }
        else
        {
            echo "Something is wrong! ";
        }
      }
      else
      {
          //It means you navigated by clicking on 
          //Add Record Link provided in 051PuneDemo.php
          //or
          //navigated directly to this page 
          //after log in
      }
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
<form action="052PuneDemo.php" method="POST">
    <a href="051PuneDemo.php">Go Back to List</a><br>
    <h1>Add New Record </h1>
    ENo: <input type="text" name="txtENo" id="txtENo"><br>
    EName:<input type="text" name="txtEName" id="txtEName"><br>
    EAddress: <input type="text" name="txtEAddress" id="txtEAddress"><br>
    <input type="submit" value="Add Record" name="btnAdd">

</form>
</body>
</html>