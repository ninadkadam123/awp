<?php 
    header("Content-Type:application/json");
    if(isset($_GET["email"]))
    {
        if($_GET["email"] == "m@a.com")
        {
            echo '{"message":"EMail address is taken.", "someToken" : 0}';
        }
        else
        {
            echo '{"message": "EMail address is available", "someToken": 1}';
        }
    }
    else
    {
        echo '{"message": "Please submit email","someToken" : 0}';
    }

?>