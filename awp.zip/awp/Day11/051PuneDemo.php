<?php 

    session_start();
    if(!isset($_SESSION["userName"])){
        header("location:050PuneDemo.php");
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">
    <script src="jquery-3.4.1.min.js"></script>
    <script src="bootstrap.js"></script>

</head>
<body>
    <h1>
        Welcome <?php echo $_SESSION["userName"]; ?>
        <a href="055PuneDemo.php">log out </a>
    </h1>
    <a href="052PuneDemo.php">Add New Record</a>
    <br>
    <table class="table">

    <?php 
        print_r($_SESSION);
       $refToConnection= 
                mysqli_connect("localhost","root"
                               ,"manager","AWP");

       $resultSet= 
                mysqli_query($refToConnection, 
                            "select * from Emp");

        echo mysqli_error($refToConnection);

        while($currentRow = 
                     mysqli_fetch_row($resultSet) )
        {
            //print_r($currentRow);

            echo "<tr>". 
                    "<td>" . $currentRow[0] . "</td>" . 
                    "<td>" . $currentRow[1] . "</td>" . 
                    "<td>" . $currentRow[2] . "</td>" . 
                    "<td>" . 
                        "<a href='053PuneDemo.php?ENo=". $currentRow[0] ."'>"."Edit" ."</a>" . 
                    "</td>" . 
                    "<td>" . 
                        "<a href='054PuneDemo.php?ENo=". $currentRow[0] ."'>"."Delete" ."</a>" . 
                    "</td>" . 
                 "</tr>" ;
        }
        mysqli_close($refToConnection);



    ?>

    </table>
</body>
</html>
















